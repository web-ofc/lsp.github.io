<?php

class database
{
    var $host = "localhost";
    var $username = "root";
    var $password = "";
    var $db = "db_poliklinik_dimas";

    function tampil_data()
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        $data = mysqli_query($conn, 'SELECT * FROM user');
        while ($d = mysqli_fetch_array($data)) {
            $hasil[] = $d;
        }
        return $hasil;
    }
    function tampil_transaksi1()
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        $data = mysqli_query($conn, 'SELECT * FROM transaksi');
        while ($d = mysqli_fetch_array($data)) {
            $hasil[] = $d;
        }
        return $hasil;
    }
    function tampil_pasien()
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        $data = mysqli_query($conn, 'SELECT * FROM tb_pasien');
        while ($d = mysqli_fetch_array($data)) {
            $hasil[] = $d;
        }
        return $hasil;
    }


    function input($nama, $username, $password, $level)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        mysqli_query($conn, "insert into user values('','$nama','$username','$password','$level')");
    }
    function input_transaksi($nama_pasien, $nama_dokter, $tgl_konsul, $harga_konsul, $uang_bayar)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        mysqli_query($conn, "INSERT INTO transaksi VALUES('','$nama_pasien','$nama_dokter','$tgl_konsul','$harga_konsul','$uang_bayar')");
    }
    function edit($id)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        $data = mysqli_query($conn, "SELECT * FROM user where id='$id'");
        while ($d = mysqli_fetch_array($data)) {
            $hasil[] = $d;
        }
        return $hasil;
    }
    function update($id, $nama, $username, $password, $level)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        mysqli_query($conn, "update user set nama='$nama',username='$username',password='$password', level='$level' where id='$id'");
    }
    function hapus($id)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        mysqli_query($conn, "delete from user where id='$id'");
    }
    function hapus_transaksi($id)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        mysqli_query($conn, "delete from transaksi where id_transaksi='$id'");
    }
}


$dbom = new database();
