<?php
include 'konfigurasi.php';
$dbdim = new database();
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap/css/bootstrap.min.css">
</head>
<body >
<div >
			<header class="blog-header lh-1 py-3">
				<main class="container">
                    <div class="p-4 mt-5 p-md-5 mb-4 rounded text-bg-dark">
                    <h1 class="display-5 fst-italic mb-5">PoliKlinik (USER)<br>DATA PASIEN</h1>
							<p class="lead mb-0"><a href="./logout.php" class="btn btn-outline-danger btn-sm mb-3">KELUAR</a></p>
</div>

        <table class="table mx-auto " >
    <tr>
        <th>No.</th>
        <th>Nama Pasien</th>
        <th>NIP</th>
        <th>Umur</th>
        <th>Penyakit</th>
    </tr>
<?php
$no = 1;
foreach($dbdim->tampil_pasien() as $d){
    ?>
<tr>
    <td><?php echo $no++; ?></td>
    <td><?php echo $d['nama_pasien']; ?></td>
    <td><?php echo $d['nip']; ?></td>
    <td><?php echo $d['umur']; ?></td>
    <td ><?php echo $d['penyakit']; ?></td>
    <td>
</td>
<?php
}
?>
    
</body>
</html>
