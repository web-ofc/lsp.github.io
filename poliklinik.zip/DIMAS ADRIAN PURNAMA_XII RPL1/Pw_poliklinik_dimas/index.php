
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.104.2">
    <title>halaman | Login</title>
<!-- 
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="../bootstrap/js/bootstrap.min.js"></script> -->

  </head>
  <body class="text-center d-flex align-items-center" >
    
  <main class="form-signin w-25 m-auto">
    <form action="cek_login.php" method="post">
      <h1 class="h3 mb-3 fw-normal">POLIKLINIK DOKTER OM<br><br>Silahkan Login</h1>

    <div class="mb-3">
      <label for="floatingInput">Username</label>
      <input type="text" name="username" class="form-control" id="floatingInput" placeholder="Username..">
    </div>
    <div class="mb-3">
      <label for="floatingPassword">Password</label>
      <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password..">
    </div>

    <button class="btn btn-secondary " type="submit">Bisa</button>
  </form>
</main>


    
  </body>
</html>
