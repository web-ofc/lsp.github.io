<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Transaksi</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>

 
<div class="container">
			<header class="blog-header lh-1 py-3">
				<main class="container">
                    <div class="p-4 mt-5 p-md-5 mb-4 rounded text-bg-dark">
                    <h1 class="display-5 fst-italic mb-5">INPUT TRANSAKSI<br>ADMIN</h1>
</div>



        <div class="container">

            <form action="proses.php?aksi=tambahtransmin" method="POST">

                <div class="mb-3">
                    <label>Nama Pasien</label>
                    <input type="text" name="nama_pasien" class="form-control">
                </div>
                <div class="mb-3">
                    <label>Nama Dokter</label>
                    <input type="text" name="nama_dokter" class="form-control">
                </div>
                <div class="mb-3">
                    <label>Tanggal Konsul</label>
                    <input type="date" name="tgl_konsul" class="form-control">
                </div>
                <div class="mb-3">
                    <label>Harga Konsultasi</label>
                    <input type="text" name="harga_konsul" class="form-control">
                </div>
                <div class="mb-3">
                    <label>Uang Bayar</label>
                    <input type="text" name="uang_bayar" class="form-control">
                </div>

                <button class="btn btn-sm btn-outline-secondary d-flex mx-auto" type="submit">Tambah</button>
            </form>
        </div>
    </div>
</body>

</html>