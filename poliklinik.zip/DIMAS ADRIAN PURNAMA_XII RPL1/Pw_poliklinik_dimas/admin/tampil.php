<?php
include 'konfigurasi.php';
$dbom = new database();
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampil Admin</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>


<div class="container">
			<header class="blog-header lh-1 py-3">
				<main class="container">
                    <div class="p-4 mt-5 p-md-5 mb-4 rounded text-bg-dark">
                    <h1 class="display-5 fst-italic mb-5">PoliKlinik (Admin)<br>INPUT USER ADMIN</h1>

            <a class="btn btn-outline-primary btn-sm mb-3" href="inputuser.php">INPUT USER BARU</a>
            <a class="btn btn-outline-primary btn-sm mb-3" href="transaksi.php">Transaksi</a>
            <a class="btn btn-outline-primary btn-sm mb-3" href="index.php">Kembali</a>
</ul>
</div>
        <table class="table">
            <tr>
                <th>No.</th>
                <th>Nama</th>
                <th>Username</th>
                <th>Password</th>
                <th>Level</th>
                <th>Edit</th>
                <th>Hapus</th>
            </tr>
            <?php
            $no = 1;
            foreach ($dbom->tampil_data() as $d) {
            ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $d['nama']; ?></td>
                    <td><?php echo $d['username']; ?></td>
                    <td><?php echo $d['password']; ?></td>
                    <td><?php echo $d['level']; ?></td>
                    <td><a href="edituser.php?id=<?php echo $d['id']; ?>&aksi=edit">EDIT</a></td>
                    <td><a href="proses.php?id=<?php echo $d['id']; ?>&aksi=hapus">DELETE</a></td>
                    <td>
                    </td>
                <?php
            }
                ?>
    </div>
    </div>
</body>

</html>