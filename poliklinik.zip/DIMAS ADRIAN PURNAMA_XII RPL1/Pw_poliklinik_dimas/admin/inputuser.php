<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah User</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body class="d-flex justify-content-center align-items-center">
<div>
			<header class="blog-header lh-1 py-3">
                    <div class="p-4 mt-5 p-md-5 mb-4 rounded text-bg-dark">
                    <h1 class="display-5 fst-italic mb-5">PoliKlinik (Admin)<br>INPUT USER ADMIN</h1>
                    <a class="btn btn-outline-primary btn-sm mb-3" href="index.php">Kembali</a>
</div>
<div>
            <form action="proses.php?aksi=tambah" method="POST">
                    <label>Nama</label>
                    <input type="text" name="nama" >
        
                    <label>Username</label>
                    <input type="text" name="username">

                    <label>Password</label>
                    <input type="password" name="password">

                    <label>Level</label>
                    <select name="level" id="level">
                        <option value="admin">Admin</option>
                        <option value="pegawai">Pegawai</option>
                        <option value="user">User</option>
                    </select>
                    <br>
                    <br>
                    <button  class="btn btn-primary sm mb-3" type="submit">bisa </button>
                   </form>
    </div>

</body>

</html>