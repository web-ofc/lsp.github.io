<?php

include 'konfigurasi.php';
$dbmas = new database();

$aksi = $_GET['aksi'];
if ($aksi == "tambah") {
    $dbmas->input($_POST['nama'], $_POST['username'], $_POST['password'], $_POST['level']);
    header("location:tampil.php");
} elseif ($aksi == "update") {
    $dbmas->update($_POST['id'], $_POST['nama'], $_POST['username'], $_POST['password'], $_POST['level']);
    header("location:tampil.php");
} elseif ($aksi == "hapus") {
    $dbmas->hapus($_GET['id']);
    header("location:tampil.php");
}
//Transaksi
if ($aksi == "tambahtransmin") {
    $dbmas->input_transaksi($_POST['nama_pasien'], $_POST['nama_dokter'], $_POST['tgl_konsul'], $_POST['harga_konsul'], $_POST['uang_bayar']);
    header("location:transaksi.php");
} elseif ($aksi == "hapustransaksi") {
    $dbmas->hapus_transaksi($_GET['id_transaksi']);
    header("location:transaksi.php");
}



