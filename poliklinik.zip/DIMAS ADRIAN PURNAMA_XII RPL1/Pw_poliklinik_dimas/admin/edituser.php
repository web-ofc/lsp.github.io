<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link href="style.css" rel="stylesheet" type="text/css">
</head>

<div class="container">
			<header class="blog-header lh-1 py-3">
				<main class="container">
                    <div class="p-4 mt-5 p-md-5 mb-4 rounded text-bg-dark">
                    <h1 class="display-5 fst-italic mb-5">PoliKlinik (Admin)<br>EDIT USER</h1>
                    <a class="btn btn-outline-primary btn-sm mb-3" href="index.php">Kembali</a>
</div>

<?php 
include 'konfigurasi.php';
$dbom = new database();
?>
<form action ="proses.php?aksi=update" method="POST">
    <?php
    foreach($dbom->edit($_GET['id']) as $d){
    ?>
  
    <input type="hidden" name="id" value="<?=$d ['id']?>">
    <tr>Nama :</tr>
    <input type="text" name="nama" value="<?=$d ['nama']?>">
    <p>
    <tr>Username :</tr>
    <input type="text" name="username" value="<?=$d ['username']?>">
    <p>
    <tr>Password :</tr>
    <input type="text" name="password" value="<?=$d ['password']?>">
    <p>
    <tr>Level :</tr>
    <select name="level" id="level">
    <option value="<?=$d ['level']?>">"<?=$d ['level']?>"</option>
    <option value="admin">Admin</option>
    <option value="pegawai">Pegawai</option>
    <option value="user">User</option>
    <br>
    <br>
    <input type="submit" value="Edit"/>
    <?php
    }
    ?>
</form>
