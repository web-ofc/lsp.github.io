<!DOCTYPE html>
<html>
<head>
	<title>Halaman admin</title>
</head>
<body>
	
	<?php 
	session_start();
 
	// cek apakah yang mengakses halaman ini sudah login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=gagal");
	}
 
	?>


</body>

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
		<meta name="generator" content="Hugo 0.104.2">


		<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
	</head>

	<body>

		<div class="container">
			<header class="blog-header lh-1 py-3">


				<main class="container">
					<div class="p-4 mt-5 p-md-5 mb-4 rounded text-bg-dark">
						<div class="col-md-6 px-0">
							<h1 class="display-5 fst-italic mb-5">Hallo<?php echo $_SESSION['username']; ?>,</b> Anda telah login sebagai <b><?php echo $_SESSION['level']; ?></h1>
							<p class="lead mb-0"><a href="./logout.php" class="btn btn-sm btn-outline-primary w-25">Log Out</a></p>
						</div>
					</div>

					<div class="row mb-2">
						<div class="col-md-6">
							<div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
								<div class="col p-4 d-flex flex-column position-static">
									<h3 class="mb-1">Manager User</h3>
									<a href="tampil.php" class="btn btn-sm btn-outline-secondary w-25">Tampil</a>
								</div>
								<div class="col-auto d-none d-lg-block">
									<img src="../gambardimas/images.png" class="bd-placeholder-img mt-3 me-5" width="250" height="200" xm role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false">

								</div>
							</div>
						</div>
						
					</div>


				</main>

	</body>

	</html>