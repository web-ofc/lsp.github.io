<?php
include 'konfigurasi.php';
$dbdimas = new database();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <title>Pasien</title>
</head>
<div>
<body class="d-flex justify-content-center align-items-center">
<div class="container">
			<header class="blog-header lh-1 py-3">
				<main class="container">
                    <div class="p-4 mt-5 p-md-5 mb-4 rounded text-bg-dark">
                    <h1 class="display-5 fst-italic mb-3">INPUT TRANSAKSI<br>ADMIN</h1>
</div>
       
        <a class="btn btn-outline-danger btn-sm mb-3" href="inputtransaksi.php">Tambah Transaksi</a>
        <a class="btn btn-outline-danger btn-sm mb-3" href="tampil.php">Kembali</a>
        <table class="table">
        
            <tr>
                <th>No.</th>
                <th>Nama Pasien</th>
                <th>Nama Dokter</th>
                <th>Tanggal Konsul</th>
                <th>Harga Konsul</th>
                <th>Uang Bayar</th>
                <th>Kembalian</th>
            </tr>
            <?php
            $no = 1;
            foreach ($dbdimas->tampil_transaksi1() as $x) {
            ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $x['nama_pasien']; ?></td>
                    <td><?php echo $x['nama_dokter']; ?></td>
                    <td><?php echo $x['tgl_konsul']; ?></td>
                    <td><?php echo $x['harga_konsul']; ?></td>
                    <td><?php echo $x['uang_bayar']; ?></td>
                    <td><?php $kembalian = $x['uang_bayar'] - $x['harga_konsul'];
                        echo $kembalian;
                        ?>
                    <td><a href="proses.php?id_transaksi=<?php echo $x['id_transaksi']; ?>&aksi=hapustransaksi">DELETE</a></td>
                    <td>
                    </td>
                <?php
            }
                ?>
    </div>

</body>

</html>