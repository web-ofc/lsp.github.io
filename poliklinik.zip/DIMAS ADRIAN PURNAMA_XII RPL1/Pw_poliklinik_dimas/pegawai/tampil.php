<?php
include 'konfigurasi.php';
$dbom = new database();
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampil Pegawai</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>


<div class="container">
			<header class="blog-header lh-1 py-3">
				<main class="container">
                    <div class="p-4 mt-5 p-md-5 mb-4 rounded text-bg-dark">
                    <h1 class="display-5 fst-italic mb-5">PoliKlinik (Admin)<br>DATA PASIEN</h1>

        <a class="btn btn-outline-danger btn-sm mb-3" href="inputpasien.php">TAMBAH PASIEN +</a>
        <a class="btn btn-outline-danger btn-sm mb-3" href="transaksi.php">Transaksi</a>
        <a class="btn btn-outline-danger btn-sm mb-3" href="index.php">Kembali</a>
</div>
        <table class="table">
            <tr>
                <th>No.</th>
                <th>NIP</th>
                <th>Nama Pasien</th>
                <th>Umur</th>
                <th>Penyakit</th>
                <th>Edit</th>
                <th>Hapus</th>
            </tr>
            <?php
            $no = 1;
            foreach ($dbom->tampil_data() as $d) {
            ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $d['nip']; ?></td>
                    <td><?php echo $d['nama_pasien']; ?></td>
                    <td><?php echo $d['umur']; ?></td>
                    <td><?php echo $d['penyakit']; ?></td>
                    <td><a class="btn btn-outline-secondary btn-sm mb-2" href="editpasien.php?id=<?php echo $d['id']; ?>&aksi=edit">EDIT</a></td>
                    <td><a class="btn btn-outline-secondary btn-sm mb-2" href="proses.php?id=<?php echo $d['id']; ?>&aksi=hapus">DELETE</a></td>
                    <td>
                    </td>
                <?php
            }
                ?>
    </div>

</body>

</html>