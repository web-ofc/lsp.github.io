<?php

class database
{
    var $host = "localhost";
    var $username = "root";
    var $password = "";
    var $db = "db_poliklinik_dimas";

    function tampil_data()
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        $data = mysqli_query($conn, 'SELECT * FROM tb_pasien');
        while ($d = mysqli_fetch_array($data)) {
            $hasil[] = $d;
        }
        return $hasil;
    }
    function tampil_transaksi()
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        $data = mysqli_query($conn, 'SELECT * FROM transaksi');
        while ($d = mysqli_fetch_array($data)) {
            $hasil[] = $d;
        }
        return $hasil;
    }

    function input($nip, $nama_pasien, $umur, $penyakit)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        mysqli_query($conn, "insert into tb_pasien values('','$nip','$nama_pasien','$umur','$penyakit')");
    }
    function input_transaksi($nama_pasien, $nama_dokter, $tgl_konsul, $harga_konsul, $uang_bayar)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        mysqli_query($conn, "insert into transaksi values('','$nama_pasien','$nama_dokter','$tgl_konsul','$harga_konsul','$uang_bayar')");
    }
    function edit($id)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        $data = mysqli_query($conn, "SELECT * FROM tb_pasien where id='$id'");
        while ($d = mysqli_fetch_array($data)) {
            $hasil[] = $d;
        }
        return $hasil;
    }
    function update($id, $nip, $nama_pasien, $umur, $penyakit)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        mysqli_query($conn, "update tb_pasien set nip='$nip',nama_pasien='$nama_pasien',umur='$umur', penyakit='$penyakit' where id='$id'");
    }
    function hapus($id)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        mysqli_query($conn, "delete from tb_pasien where id='$id'");
    }
    function hapus_transaksi1($id_transaksi)
    {
        $conn = mysqli_connect($this->host, $this->username, $this->password, $this->db);
        mysqli_query($conn, "delete from transaksi where id_transaksi='$id_transaksi'");
    }
}
