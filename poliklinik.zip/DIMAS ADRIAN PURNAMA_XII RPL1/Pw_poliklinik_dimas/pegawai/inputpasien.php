<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <title>Tambah Pasien</title>
    
</head>
<div class="container">
			<header class="blog-header lh-1 py-3">
				<main class="container">
                    <div class="p-4 mt-5 p-md-5 mb-4 rounded text-bg-dark">
                    <h1 class="display-5 fst-italic mb-5">INPUT PASIEN<br>PASIEN</h1>
                    <a class="btn btn-outline-primary btn-sm mb-3" href="tampil.php">Kembali</a>
</div>



        <div class="container"> 

            <form action="proses.php?aksi=tambah" method="POST">

                <div class="mb-2">
                    <label>Nama Pasien</label>
                    <input type="text" name="nama_pasien" class="form-control">
                </div>
                <div class="mb-2">
                    <label>nip</label>
                    <input type="text" name="nip" class="form-control">
                </div>
                <div class="mb-2">
                    <label>umur</label>
                    <input type="text" name="umur" class="form-control">
                </div>
                <div class="mb-2">
                    <label>penyakit</label>
                    <input type="text" name="penyakit" class="form-control">
                </div>
               
                <button  class="btn btn-primary sm mb-4" type="submit">BISA</button>

            </form>
</div>
</body>

</html>