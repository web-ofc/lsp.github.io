<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Transaksi</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>

<body>

    <div class="container d-flex justify-content-center align-items-center" style="padding-top: 120px;">


        <div class="card border-0">

            <h5 class="mb-4">Input Transaksi (Admin)</h5>

            <form action="proses.php?aksi=tambahtransmin" method="POST">

                <div class="mb-2">
                    <label>Nama Pasien</label>
                    <input type="text" name="nama_pasien" class="form-control">
                </div>
                <div class="mb-2">
                    <label>Nama Dokter</label>
                    <input type="text" name="nama_dokter" class="form-control">
                </div>
                <div class="mb-2">
                    <label>Tanggal Konsul</label>
                    <input type="date" name="tgl_konsul" class="form-control">
                </div>
                <div class="mb-2">
                    <label>Harga Konsultasi</label>
                    <input type="text" name="harga_konsul" class="form-control">
                </div>
                <div class="mb-2">
                    <label>Uang Bayar</label>
                    <input type="text" name="uang_bayar" class="form-control">
                </div>

                <button class="btn btn-sm btn-outline-secondary d-flex mx-auto" type="submit">Tambah</button>
            </form>
        </div>
    </div>
</body>

</html>