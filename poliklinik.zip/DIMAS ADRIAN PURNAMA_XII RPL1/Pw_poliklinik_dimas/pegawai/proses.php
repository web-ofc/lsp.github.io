<?php

include 'konfigurasi.php';
$dbdimas = new database();

$aksi = $_GET['aksi'];
if ($aksi == "tambah") {
    $dbdimas->input($_POST['nip'], $_POST['nama_pasien'], $_POST['umur'], $_POST['penyakit']);
    header("location:tampil.php");
} elseif ($aksi == "update") {
    $dbdimas->update($_POST['id'], $_POST['nip'], $_POST['nama_pasien'], $_POST['umur'], $_POST['penyakit']);
    header("location:tampil.php");
} elseif ($aksi == "hapus") {
    $dbdimas->hapus($_GET['id']);
    header("location:tampil.php");
}
//Transaksi
elseif ($aksi == "tambahtransmin") {
    $dbdimas->input_transaksi($_POST['nama_pasien'], $_POST['nama_dokter'], $_POST['tgl_konsul'], $_POST['harga_konsul'], $_POST['uang_bayar']);
    header("location:transaksi.php");
} elseif ($aksi == "hapustransaksi1") {
    $dbdimas->hapus_transaksi1($_GET['id_transaksi']);
    header("location:transaksi.php");
}

