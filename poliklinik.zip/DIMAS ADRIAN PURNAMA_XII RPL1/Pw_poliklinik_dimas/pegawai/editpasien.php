<?php 
include 'konfigurasi.php';
$dbom = new database();
?>
 <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<form action ="proses.php?aksi=update" method="POST">
<div class="container">
			<header class="blog-header lh-1 py-3">
				<main class="container">
                    <div class="p-4 mt-5 p-md-5 mb-4 rounded text-bg-dark">
                    <h1 class="display-5 fst-italic mb-5">PoliKlinik (Pegawai)<br>EDIT Pasien</h1>
                    <a class="btn btn-outline-primary btn-sm mb-3" href="index.php">Kembali</a>
</div>
    <?php
    foreach($dbom->edit($_GET['id']) as $d){
    ?>
    <div class="form-control">
        <input  type="hidden" name="id" value="<?=$d ['id']?>">
    <center>
        <p>
    <tr>Nama Pasien :</tr>
    
    <input type="text" name="nama_pasien" value="<?=$d ['nama_pasien']?>"  ">
    <p>
    <tr>NIP:</tr>
    <input type="text" name="nip" value="<?=$d ['nip']?>"  ">
    <p>
    <tr>Umur :</tr>
    <input type="text" name="umur" value="<?=$d ['umur']?>"  ">
    <p>
    <tr>Penyakit :</tr>
    <input type="text" name="penyakit" value="<?=$d ['penyakit']?>"  ">
    <p>
    </center>
    <button class="btn btn-sm btn-outline-secondary d-flex mx-auto" type="submit">Tambah</button>
    </div>
    <?php
    }
    ?>
</form>
