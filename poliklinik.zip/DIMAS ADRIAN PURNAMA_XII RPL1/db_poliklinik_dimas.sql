-- phpMyAdmin SQL Dump
-- version 5.3.0-dev+20221125.2e001c186a
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2023 at 02:29 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_poliklinik_dimas`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkup`
--

CREATE TABLE `checkup` (
  `id_checkup` int(11) NOT NULL,
  `id_pasien` int(11) NOT NULL,
  `id_dokter` int(11) NOT NULL,
  `tgl_konsul` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `checkup`
--

INSERT INTO `checkup` (`id_checkup`, `id_pasien`, `id_dokter`, `tgl_konsul`) VALUES
(1, 3, 2, '2023-02-07'),
(2, 7, 1, '2023-02-08');

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE `dokter` (
  `id_dokter` int(11) NOT NULL,
  `nomer_dok` int(50) NOT NULL,
  `nama_dokter` varchar(255) NOT NULL,
  `jk_dokter` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`id_dokter`, `nomer_dok`, `nama_dokter`, `jk_dokter`) VALUES
(1, 2211, 'sdfa', 'laki'),
(2, 1232, 'Noyaa', 'Cewe');

-- --------------------------------------------------------

--
-- Table structure for table `log_pasien`
--

CREATE TABLE `log_pasien` (
  `kejadian` varchar(50) NOT NULL,
  `waktu` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `log_pasien`
--

INSERT INTO `log_pasien` (`kejadian`, `waktu`) VALUES
('Tambah Data', '2023-02-12 20:28:59'),
('Update Data', '2023-02-12 20:29:18'),
('Hapus Data', '2023-02-12 20:29:26');

-- --------------------------------------------------------

--
-- Table structure for table `tb_obat`
--

CREATE TABLE `tb_obat` (
  `id_obat` int(11) NOT NULL,
  `nama_obat` varchar(100) NOT NULL,
  `stok` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_obat`
--

INSERT INTO `tb_obat` (`id_obat`, `nama_obat`, `stok`) VALUES
(1, 'paracetamol', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pasien`
--

CREATE TABLE `tb_pasien` (
  `id` int(10) NOT NULL,
  `nama_pasien` varchar(100) NOT NULL,
  `nip` varchar(10) NOT NULL,
  `umur` int(11) NOT NULL,
  `penyakit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_pasien`
--

INSERT INTO `tb_pasien` (`id`, `nama_pasien`, `nip`, `umur`, `penyakit`) VALUES
(3, 'dias', '22222', 1234, 'saraf'),
(7, 'dimas', '0012', 18, 'sehat'),
(12, '232', 'sda', 12, 'ds'),
(15, 'dimas', '77120199', 17, 'medical');

--
-- Triggers `tb_pasien`
--
DELIMITER $$
CREATE TRIGGER `hapus_pasien` AFTER DELETE ON `tb_pasien` FOR EACH ROW INSERT INTO log_pasien VALUES ('Hapus Data', now())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tambah_pasien` AFTER INSERT ON `tb_pasien` FOR EACH ROW INSERT INTO log_pasien VALUES ('Tambah Data', now())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_pasien` AFTER UPDATE ON `tb_pasien` FOR EACH ROW INSERT INTO log_pasien VALUES ('Update Data', now())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `nama_pasien` varchar(100) NOT NULL,
  `nama_dokter` varchar(255) NOT NULL,
  `tgl_konsul` date NOT NULL,
  `harga_konsul` int(100) NOT NULL,
  `uang_bayar` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `nama_pasien`, `nama_dokter`, `tgl_konsul`, `harga_konsul`, `uang_bayar`) VALUES
(9, 'dimas', 'yooii', '2023-02-21', 10000, 20000),
(11, 'iyann', 'dokter amin', '2023-02-22', 10000, 30000),
(13, 'WREW', 'REWR', '2023-02-22', 10000, 40000),
(14, 'dfds', 'dsfd', '2023-02-22', 20000, 300000),
(15, 'asas', 'dimas', '2023-02-17', 20000, 40000);

--
-- Triggers `transaksi`
--
DELIMITER $$
CREATE TRIGGER `kurangi_obat` AFTER INSERT ON `transaksi` FOR EACH ROW BEGIN
UPDATE tb_obat SET stok = stok -1
WHERE id_obat=tb_obat.id_obat;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`, `level`) VALUES
(7, 'admin', 'admin', '12345678', 'admin'),
(8, 'user', 'user', '12345678', 'user'),
(9, 'a', 'a', 'a', 'admin'),
(15, 'dim', 'd', 'd', 'admin'),
(21, 'sssssss', 'aaaaa', 'effff', 'admin'),
(22, 'vrff', 'fff', 'f4fff', 'user'),
(24, 'pe', 'pe', 'pe', 'pegawai');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `checkup`
--
ALTER TABLE `checkup`
  ADD PRIMARY KEY (`id_checkup`),
  ADD UNIQUE KEY `id_pasien` (`id_pasien`,`id_dokter`),
  ADD KEY `id_dokter` (`id_dokter`);

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
  ADD PRIMARY KEY (`id_dokter`);

--
-- Indexes for table `tb_obat`
--
ALTER TABLE `tb_obat`
  ADD PRIMARY KEY (`id_obat`);

--
-- Indexes for table `tb_pasien`
--
ALTER TABLE `tb_pasien`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `checkup`
--
ALTER TABLE `checkup`
  MODIFY `id_checkup` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dokter`
--
ALTER TABLE `dokter`
  MODIFY `id_dokter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_obat`
--
ALTER TABLE `tb_obat`
  MODIFY `id_obat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_pasien`
--
ALTER TABLE `tb_pasien`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `checkup`
--
ALTER TABLE `checkup`
  ADD CONSTRAINT `checkup_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `tb_pasien` (`id`),
  ADD CONSTRAINT `checkup_ibfk_2` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id_dokter`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
